package common;
import net.bytebuddy.asm.MemberSubstitution;
import org.openqa.selenium.WebDriver;
public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL = "http://railwayb1.somee.com/Page/HomePage.cshtml";
    public static final String USERNAME = "Hong123@gmail.com";
    public static final String PASSWORD = "Hong12345678";
}

